/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/* $Id$ */

package org.apache.fop.render;

/**
 * This interface is used by the Graphics2DAdapter. Components that can paint using
 * a Graphics2D instance can implement this interface to paint themselves.
 * @deprecated use {@link org.apache.xmlgraphics.java2d.Graphics2DImagePainter} directly!
 */
// @SuppressFBWarnings("NM_SAME_SIMPLE_NAME_AS_INTERFACE")
public interface Graphics2DImagePainter
        extends org.apache.xmlgraphics.java2d.Graphics2DImagePainter {

}
